import requests
import json
import logging
from datetime import datetime
from config import API_URL, CLIENT_VERSION, IMPRESSIONS_CACHE_FILE
from pathlib import Path

logger = logging.getLogger(__name__)


class APIClient:
    def __init__(self, device_uuid: str):
        self.device_uuid = device_uuid
        self.base_url = API_URL
        self.session = requests.Session()

    def register_device(self, device_name: str) -> bool:
        """Registrar dispositivo na API"""
        try:
            url = f"{self.base_url}/api/devices/client/register"
            data = {
                "device_uuid": self.device_uuid,
                "device_name": device_name,
                "client_version": CLIENT_VERSION
            }
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            logger.info(f"Dispositivo registrado: {response.json()}")
            return True
        except Exception as e:
            logger.error(f"Erro ao registrar dispositivo: {e}")
            return False

    def send_heartbeat(self) -> bool:
        """Enviar heartbeat para o servidor"""
        try:
            url = f"{self.base_url}/api/devices/client/heartbeat"
            data = {
                "device_uuid": self.device_uuid,
                "client_version": CLIENT_VERSION
            }
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            logger.info("Heartbeat enviado com sucesso")
            return True
        except Exception as e:
            logger.error(f"Erro ao enviar heartbeat: {e}")
            return False

    def get_advertisements(self) -> dict:
        """Obter lista de anúncios para este dispositivo"""
        try:
            url = f"{self.base_url}/api/client/advertisements/{self.device_uuid}"
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            logger.info("Anúncios obtidos com sucesso")
            return response.json()
        except Exception as e:
            logger.error(f"Erro ao obter anúncios: {e}")
            return {"device_uuid": self.device_uuid, "advertisements": []}

    def download_advertisement(self, advertisement_id: int, save_path: str) -> bool:
        """Baixar arquivo de anúncio"""
        try:
            url = f"{self.base_url}/api/advertisements/download/{advertisement_id}"
            response = self.session.get(url, timeout=30, stream=True)
            response.raise_for_status()
            
            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
            
            logger.info(f"Anúncio {advertisement_id} baixado: {save_path}")
            return True
        except Exception as e:
            logger.error(f"Erro ao baixar anúncio {advertisement_id}: {e}")
            return False

    def record_impression(self, advertisement_id: int, started_at: datetime, 
                         finished_at: datetime, duration_seconds: int) -> bool:
        """Registrar impressão de anúncio"""
        try:
            url = f"{self.base_url}/api/impressions"
            data = {
                "device_uuid": self.device_uuid,
                "advertisement_id": advertisement_id,
                "started_at": started_at.isoformat(),
                "finished_at": finished_at.isoformat(),
                "duration_seconds": duration_seconds
            }
            
            response = self.session.post(url, json=data, timeout=10)
            response.raise_for_status()
            
            logger.info(f"Impressão registrada: Ad {advertisement_id}")
            return True
        except Exception as e:
            logger.error(f"Erro ao registrar impressão: {e}")
            # Salvar localmente para sincronizar depois
            self._save_impression_cache(data)
            return False

    def _save_impression_cache(self, impression_data: dict):
        """Salvar impressão em cache local para sincronizar depois"""
        try:
            impressions = []
            if IMPRESSIONS_CACHE_FILE.exists():
                with open(IMPRESSIONS_CACHE_FILE, 'r') as f:
                    impressions = json.load(f)
            
            impressions.append(impression_data)
            
            with open(IMPRESSIONS_CACHE_FILE, 'w') as f:
                json.dump(impressions, f)
            
            logger.info("Impressão salva em cache local")
        except Exception as e:
            logger.error(f"Erro ao salvar impressão em cache: {e}")

    def sync_cached_impressions(self) -> bool:
        """Sincronizar impressões em cache com o servidor"""
        try:
            if not IMPRESSIONS_CACHE_FILE.exists():
                return True
            
            with open(IMPRESSIONS_CACHE_FILE, 'r') as f:
                impressions = json.load(f)
            
            if not impressions:
                return True
            
            synced_count = 0
            for imp in impressions:
                url = f"{self.base_url}/api/impressions"
                try:
                    response = self.session.post(url, json=imp, timeout=10)
                    response.raise_for_status()
                    synced_count += 1
                except:
                    pass
            
            if synced_count > 0:
                # Remover impressões sincronizadas
                IMPRESSIONS_CACHE_FILE.unlink()
                logger.info(f"{synced_count} impressões sincronizadas")
            
            return True
        except Exception as e:
            logger.error(f"Erro ao sincronizar impressões: {e}")
            return False
