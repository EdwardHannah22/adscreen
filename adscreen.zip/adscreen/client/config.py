import os
from pathlib import Path

# Diretórios
APP_DIR = Path(__file__).parent
STORAGE_DIR = APP_DIR / "storage"
CACHE_DIR = STORAGE_DIR / "cache"
LOGS_DIR = STORAGE_DIR / "logs"

# Criar diretórios se não existirem
STORAGE_DIR.mkdir(exist_ok=True)
CACHE_DIR.mkdir(exist_ok=True)
LOGS_DIR.mkdir(exist_ok=True)

# Configuração
API_URL = os.getenv("API_URL", "http://localhost:8000")
IDLE_TIMEOUT_SECONDS = int(os.getenv("IDLE_TIMEOUT", "300"))  # 5 minutos
CLIENT_VERSION = "1.0.0"

# Arquivo de configuração local
CONFIG_FILE = STORAGE_DIR / "client.config"
IMPRESSIONS_CACHE_FILE = CACHE_DIR / "impressions.json"
ADVERTISEMENTS_CACHE_FILE = CACHE_DIR / "advertisements.json"
