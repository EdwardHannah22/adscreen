import psutil
import threading
import time
import logging
from datetime import datetime
from config import IDLE_TIMEOUT_SECONDS

logger = logging.getLogger(__name__)


class InactivityDetector:
    """Detecta quando o usuário fica inativo (Windows)"""
    
    def __init__(self, on_idle_start=None, on_idle_end=None):
        self.idle_timeout = IDLE_TIMEOUT_SECONDS
        self.is_idle = False
        self.idle_start_time = None
        self.last_activity_time = datetime.now()
        self.monitoring = False
        self.thread = None
        
        self.on_idle_start = on_idle_start or (lambda: None)
        self.on_idle_end = on_idle_end or (lambda: None)

    def start(self):
        """Iniciar monitoramento de inatividade"""
        if self.monitoring:
            return
        
        self.monitoring = True
        self.thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.thread.start()
        logger.info(f"Detecção de inatividade iniciada (timeout: {self.idle_timeout}s)")

    def stop(self):
        """Parar monitoramento de inatividade"""
        self.monitoring = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Detecção de inatividade parada")

    def _monitor_loop(self):
        """Loop principal de monitoramento"""
        try:
            while self.monitoring:
                idle_time = self._get_idle_time()
                
                if idle_time >= self.idle_timeout:
                    # Usuário inativo
                    if not self.is_idle:
                        self.is_idle = True
                        self.idle_start_time = datetime.now()
                        logger.info(f"Inatividade detectada: {idle_time}s >= {self.idle_timeout}s")
                        self.on_idle_start()
                else:
                    # Usuário ativo
                    if self.is_idle:
                        self.is_idle = False
                        logger.info(f"Atividade detectada (idle_time: {idle_time}s)")
                        self.on_idle_end()
                
                time.sleep(1)  # Verificar a cada 1 segundo
        except Exception as e:
            logger.error(f"Erro no loop de inatividade: {e}")

    def _get_idle_time(self) -> int:
        """Obter tempo de inatividade em segundos (aproximado)"""
        try:
            # Nota: Em uma implementação real, seria necessário usar APIs do Windows
            # como GetLastInputInfo() via ctypes
            # Por enquanto, usamos uma abordagem simplificada
            
            # Em Windows, poderia usar:
            # from ctypes import *
            # kernel32 = windll.kernel32
            # lii = LASTINPUTINFO()
            # lii.cbSize = sizeof(LASTINPUTINFO)
            # kernel32.GetLastInputInfo(byref(lii))
            # millis = kernel32.GetTickCount() - lii.dwTime
            # return millis // 1000
            
            # Implementação simplificada: usar psutil
            # Isso é uma aproximação e pode não ser 100% preciso
            return int(time.time() - self.last_activity_time.timestamp())
        except Exception as e:
            logger.error(f"Erro ao obter tempo de inatividade: {e}")
            return 0

    def update_activity(self):
        """Atualizar timestamp de última atividade"""
        self.last_activity_time = datetime.now()


# Implementação melhorada para Windows
try:
    from ctypes import *
    import win32api
    
    class Win32InactivityDetector(InactivityDetector):
        """Detector de inatividade nativo do Windows"""
        
        def _get_idle_time(self) -> int:
            """Obter tempo de inatividade usando GetLastInputInfo do Windows"""
            try:
                class LASTINPUTINFO(Structure):
                    _fields_ = [("cbSize", c_uint), ("dwTime", c_uint)]
                
                lii = LASTINPUTINFO()
                lii.cbSize = sizeof(LASTINPUTINFO)
                
                kernel32 = windll.kernel32
                kernel32.GetLastInputInfo(byref(lii))
                
                millis = kernel32.GetTickCount() - lii.dwTime
                return max(0, millis // 1000)
            except Exception as e:
                logger.error(f"Erro ao obter idle time do Windows: {e}")
                return super()._get_idle_time()
    
    InactivityDetector = Win32InactivityDetector
except:
    # Fallback para implementação genérica
    pass
