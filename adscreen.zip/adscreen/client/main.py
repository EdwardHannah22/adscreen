#!/usr/bin/env python3
"""
AdScreen Client - Cliente de publicidade digital para Windows
"""

import logging
import time
import uuid
import json
import threading
from datetime import datetime
from pathlib import Path

from config import (
    APP_DIR, STORAGE_DIR, CACHE_DIR, LOGS_DIR,
    API_URL, IDLE_TIMEOUT_SECONDS, CLIENT_VERSION, CONFIG_FILE, ADVERTISEMENTS_CACHE_FILE
)
from api import APIClient
from inactivity import InactivityDetector
from player import VideoPlayer

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(LOGS_DIR / "client.log"),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


class AdScreenClient:
    """Cliente AdScreen principal"""
    
    def __init__(self):
        self.device_uuid = self._get_or_create_uuid()
        self.api = APIClient(self.device_uuid)
        self.player = VideoPlayer(on_video_finished=self._on_video_finished)
        self.detector = InactivityDetector(
            on_idle_start=self._on_idle_start,
            on_idle_end=self._on_idle_end
        )
        self.is_running = False
        self.is_in_fullscreen = False
        self.current_impression_start = None
        self.advertisements = []
        self.current_ad_index = 0
        
        logger.info(f"AdScreen Client iniciado - UUID: {self.device_uuid}")

    def _get_or_create_uuid(self) -> str:
        """Obter ou criar UUID do dispositivo"""
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, 'r') as f:
                    config = json.load(f)
                    return config.get('device_uuid')
            except:
                pass
        
        # Criar novo UUID
        new_uuid = str(uuid.uuid4())
        config = {'device_uuid': new_uuid}
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f)
        
        return new_uuid

    def start(self):
        """Iniciar cliente"""
        try:
            self.is_running = True
            logger.info("Iniciando AdScreen Client...")
            
            # Registrar dispositivo
            if not self.api.register_device(f"AdScreen-{self.device_uuid[:8]}"):
                logger.warning("Falha ao registrar dispositivo, tentando continuar...")
            
            # Iniciar detector de inatividade
            self.detector.start()
            
            # Iniciar loops de sincronização
            threading.Thread(target=self._heartbeat_loop, daemon=True).start()
            threading.Thread(target=self._sync_loop, daemon=True).start()
            
            # Loop principal
            self._main_loop()
        except Exception as e:
            logger.error(f"Erro crítico: {e}", exc_info=True)
        finally:
            self.stop()

    def stop(self):
        """Parar cliente"""
        logger.info("Parando AdScreen Client...")
        self.is_running = False
        self.detector.stop()
        if self.is_in_fullscreen:
            self.player.stop_fullscreen()

    def _heartbeat_loop(self):
        """Loop de heartbeat para o servidor"""
        while self.is_running:
            try:
                self.api.send_heartbeat()
                time.sleep(30)  # Enviar heartbeat a cada 30 segundos
            except Exception as e:
                logger.error(f"Erro no heartbeat loop: {e}")
                time.sleep(30)

    def _sync_loop(self):
        """Loop de sincronização de dados"""
        while self.is_running:
            try:
                # Sincronizar impressões em cache
                self.api.sync_cached_impressions()
                
                # Obter anúncios atualizados
                self._fetch_advertisements()
                
                time.sleep(60)  # Sincronizar a cada 1 minuto
            except Exception as e:
                logger.error(f"Erro no sync loop: {e}")
                time.sleep(60)

    def _fetch_advertisements(self):
        """Obter anúncios do servidor"""
        try:
            data = self.api.get_advertisements()
            self.advertisements = data.get('advertisements', [])
            
            if self.advertisements:
                logger.info(f"Obtidos {len(self.advertisements)} anúncios")
                
                # Salvar em cache
                with open(ADVERTISEMENTS_CACHE_FILE, 'w') as f:
                    json.dump(self.advertisements, f)
                
                # Baixar vídeos não presentes no cache
                self._download_missing_videos()
        except Exception as e:
            logger.error(f"Erro ao obter anúncios: {e}")
            # Carregar do cache
            self._load_advertisements_from_cache()

    def _load_advertisements_from_cache(self):
        """Carregar anúncios do cache local"""
        try:
            if ADVERTISEMENTS_CACHE_FILE.exists():
                with open(ADVERTISEMENTS_CACHE_FILE, 'r') as f:
                    self.advertisements = json.load(f)
                logger.info(f"Anúncios carregados do cache: {len(self.advertisements)}")
        except Exception as e:
            logger.error(f"Erro ao carregar anúncios do cache: {e}")

    def _download_missing_videos(self):
        """Baixar vídeos que não estão em cache"""
        for ad in self.advertisements:
            video_path = CACHE_DIR / f"ad_{ad['id']}.mp4"
            
            if not video_path.exists():
                logger.info(f"Baixando anúncio {ad['id']}...")
                self.api.download_advertisement(ad['id'], str(video_path))

    def _main_loop(self):
        """Loop principal"""
        while self.is_running:
            if self.detector.is_idle and not self.is_in_fullscreen:
                self._start_fullscreen_mode()
            
            time.sleep(1)

    def _start_fullscreen_mode(self):
        """Iniciar modo fullscreen com anúncios"""
        try:
            if not self.advertisements:
                logger.warning("Nenhum anúncio disponível")
                return
            
            self.is_in_fullscreen = True
            logger.info("Entrando em modo fullscreen")
            
            # Preparar fila de vídeos
            self.player.clear_queue()
            for ad in self.advertisements:
                video_path = CACHE_DIR / f"ad_{ad['id']}.mp4"
                if video_path.exists():
                    self.player.add_video(str(video_path), ad['id'], ad['duration'])
            
            # Iniciar reprodução
            if self.player.start_fullscreen():
                # Aguardar sair do modo fullscreen
                while self.is_in_fullscreen and self.detector.is_idle:
                    time.sleep(1)
            
            self.player.stop_fullscreen()
            self.is_in_fullscreen = False
            logger.info("Saindo do modo fullscreen")
        except Exception as e:
            logger.error(f"Erro no modo fullscreen: {e}")
            self.is_in_fullscreen = False

    def _on_idle_start(self):
        """Callback quando usuário fica inativo"""
        logger.info("Usuário ficou inativo")

    def _on_idle_end(self):
        """Callback quando usuário volta a usar o computador"""
        logger.info("Usuário voltou a usar o computador")
        if self.is_in_fullscreen:
            self.is_in_fullscreen = False

    def _on_video_finished(self, advertisement_id: int, duration: int):
        """Callback quando um vídeo termina"""
        try:
            if self.current_impression_start:
                finished_at = datetime.now()
                self.api.record_impression(
                    advertisement_id,
                    self.current_impression_start,
                    finished_at,
                    duration
                )
                self.current_impression_start = None
        except Exception as e:
            logger.error(f"Erro ao registrar impressão: {e}")


def main():
    """Ponto de entrada"""
    client = AdScreenClient()
    try:
        client.start()
    except KeyboardInterrupt:
        logger.info("Interrupção do usuário")
    except Exception as e:
        logger.error(f"Erro fatal: {e}", exc_info=True)
    finally:
        client.stop()


if __name__ == "__main__":
    main()
