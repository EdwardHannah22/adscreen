import vlc
import threading
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Callable

logger = logging.getLogger(__name__)


class VideoPlayer:
    """Player de vídeos usando VLC"""
    
    def __init__(self, on_video_finished: Optional[Callable] = None):
        self.instance = vlc.Instance()
        self.media_list_player = self.instance.media_list_player_new()
        self.media_list = self.instance.media_list_new()
        self.current_video = None
        self.is_playing = False
        self.on_video_finished = on_video_finished or (lambda: None)
        self.fullscreen = False
        self.videos_queue = []
        self.current_index = 0

    def add_video(self, file_path: str, advertisement_id: int, duration: int):
        """Adicionar vídeo à fila"""
        try:
            path = Path(file_path)
            if not path.exists():
                logger.error(f"Arquivo não encontrado: {file_path}")
                return False
            
            self.videos_queue.append({
                "path": str(path),
                "ad_id": advertisement_id,
                "duration": duration
            })
            
            logger.info(f"Vídeo adicionado à fila: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Erro ao adicionar vídeo: {e}")
            return False

    def clear_queue(self):
        """Limpar fila de vídeos"""
        self.media_list.clear()
        self.videos_queue = []
        self.current_index = 0

    def start_fullscreen(self):
        """Iniciar reprodução em fullscreen"""
        try:
            if not self.videos_queue:
                logger.warning("Fila de vídeos vazia")
                return False
            
            # Preparar mídia para reprodução
            self.media_list.clear()
            for video in self.videos_queue:
                media = self.instance.media_new(video["path"])
                self.media_list.add_media(media)
            
            self.media_list_player.set_media_list(self.media_list)
            
            # Monitorar evento de término
            self.media_list_player.event_manager().event_attach(
                vlc.EventType.MediaListPlayerNextItemSet,
                self._on_video_changed
            )
            
            self.is_playing = True
            self.media_list_player.play()
            
            logger.info("Reprodução em fullscreen iniciada")
            return True
        except Exception as e:
            logger.error(f"Erro ao iniciar fullscreen: {e}")
            return False

    def stop_fullscreen(self):
        """Parar reprodução"""
        try:
            self.media_list_player.stop()
            self.is_playing = False
            self.clear_queue()
            logger.info("Reprodução parada")
            return True
        except Exception as e:
            logger.error(f"Erro ao parar reprodução: {e}")
            return False

    def _on_video_changed(self, event):
        """Callback quando um vídeo termina"""
        try:
            current_video = self.videos_queue[self.current_index]
            self.on_video_finished(
                current_video["ad_id"],
                current_video["duration"]
            )
            
            self.current_index += 1
            if self.current_index >= len(self.videos_queue):
                # Reiniciar ciclo
                self.current_index = 0
                logger.info("Ciclo de vídeos finalizado")
        except Exception as e:
            logger.error(f"Erro no callback de vídeo: {e}")

    def is_playing_status(self) -> bool:
        """Verificar se está reproduzindo"""
        return self.is_playing


class SimpleScreenDisplay:
    """Exibição simples em tela cheia (sem VLC GUI)"""
    
    def __init__(self):
        self.is_showing = False
        self.timer_thread = None

    def show_advertisement(self, file_path: str, duration: int):
        """Mostrar anúncio por X segundos"""
        self.is_showing = True
        
        # Aqui você poderia usar tkinter ou outra biblioteca
        # para criar uma janela fullscreen
        # Por enquanto, apenas simular
        
        logger.info(f"Exibindo anúncio: {file_path} por {duration}s")
        time.sleep(duration)
        
        self.is_showing = False

    def stop(self):
        """Parar exibição"""
        self.is_showing = False
