@echo off
echo Iniciando AdScreen Backend...
cd ..\backend
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
pause
