@echo off
echo Iniciando AdScreen Client...
cd ..\client
pip install -r requirements.txt
python main.py
pause
