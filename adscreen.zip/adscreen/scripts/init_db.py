#!/usr/bin/env python3
"""
Script para inicializar o banco de dados e criar usuário admin de demonstração
"""

import sys
sys.path.insert(0, '../backend')

from app.database import init_db, SessionLocal
from app.models import User, Advertiser, Establishment, UserRole
from app.auth import hash_password
from datetime import datetime

def init_database():
    """Inicializar banco e criar dados de teste"""
    
    print("Inicializando banco de dados...")
    init_db()
    print("✓ Banco de dados criado")
    
    db = SessionLocal()
    
    try:
        # Criar usuário admin
        admin_user = User(
            name="Administrador",
            email="admin@example.com",
            password_hash=hash_password("12345678"),
            role=UserRole.ADMIN
        )
        db.add(admin_user)
        db.commit()
        print("✓ Usuário admin criado (admin@example.com / 12345678)")
        
        # Criar estabelecimento de teste
        establishment = Establishment(
            name="Supermercado Centro",
            address="Rua Principal, 123",
            city="São Paulo",
            state="SP",
            latitude=-23.5505,
            longitude=-46.6333,
            status="ACTIVE"
        )
        db.add(establishment)
        db.commit()
        print("✓ Estabelecimento de teste criado")
        
        # Criar anunciante de teste
        advertiser = Advertiser(
            name="Anunciante Teste",
            company_name="Empresa de Testes",
            email="advertiser@example.com",
            phone="11999999999"
        )
        db.add(advertiser)
        db.commit()
        print("✓ Anunciante de teste criado")
        
        print("\n✓ Banco de dados inicializado com sucesso!")
        print("\nDados de teste:")
        print("- Admin: admin@example.com / 12345678")
        print("- URL API: http://localhost:8000")
        print("- URL Frontend: http://localhost:5173")
        
    except Exception as e:
        print(f"✗ Erro ao inicializar: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    init_database()
