@echo off
echo Iniciando AdScreen Frontend...
cd ..\frontend
call npm install
call npm run dev
pause
