# Documentação da API AdScreen

## 🔐 Autenticação

Todos os endpoints (exceto login e register do cliente) requerem um token JWT no header:

```
Authorization: Bearer {token}
```

### Login

```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "12345678"
}
```

**Response (200):**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer"
}
```

### Registrar Usuário

```http
POST /api/auth/register
Content-Type: application/json

{
  "name": "João Silva",
  "email": "joao@example.com",
  "password": "senha_segura_123",
  "role": "OPERATOR"
}
```

## 👤 Usuários

### Obter usuário atual

```http
GET /api/users/me
Authorization: Bearer {token}
```

### Listar todos os usuários (Admin)

```http
GET /api/users
Authorization: Bearer {token}
```

### Obter usuário por ID

```http
GET /api/users/{user_id}
Authorization: Bearer {token}
```

## 🏪 Estabelecimentos

### Criar estabelecimento (Admin)

```http
POST /api/establishments
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Supermercado Centro",
  "address": "Rua Principal, 123",
  "city": "São Paulo",
  "state": "SP",
  "latitude": -23.5505,
  "longitude": -46.6333
}
```

### Listar estabelecimentos

```http
GET /api/establishments
Authorization: Bearer {token}
```

### Obter estabelecimento por ID

```http
GET /api/establishments/{id}
Authorization: Bearer {token}
```

### Atualizar estabelecimento (Admin)

```http
PUT /api/establishments/{id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Supermercado Centro - Atualizado",
  "address": "Rua Principal, 456",
  "city": "São Paulo",
  "state": "SP"
}
```

### Deletar estabelecimento (Admin)

```http
DELETE /api/establishments/{id}
Authorization: Bearer {token}
```

## 💻 Dispositivos

### Criar dispositivo (Admin)

```http
POST /api/devices
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Tela Entrada",
  "establishment_id": 1
}
```

### Listar dispositivos

```http
GET /api/devices
Authorization: Bearer {token}
```

### Obter dispositivo por ID

```http
GET /api/devices/{id}
Authorization: Bearer {token}
```

### Atualizar dispositivo (Admin)

```http
PUT /api/devices/{id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Tela Entrada - Atualizada",
  "establishment_id": 1
}
```

### Deletar dispositivo (Admin)

```http
DELETE /api/devices/{id}
Authorization: Bearer {token}
```

## 📢 Campanhas

### Criar campanha (Advertiser)

```http
POST /api/campaigns
Authorization: Bearer {token}
Content-Type: application/json

{
  "advertiser_id": 1,
  "name": "Promoção Especial",
  "description": "Descrição da campanha",
  "start_date": "2024-01-01T00:00:00",
  "end_date": "2024-01-31T23:59:59",
  "status": "DRAFT",
  "budget": 1000.00
}
```

### Listar campanhas

```http
GET /api/campaigns
Authorization: Bearer {token}
```

### Obter campanha por ID

```http
GET /api/campaigns/{id}
Authorization: Bearer {token}
```

### Atualizar campanha (Advertiser)

```http
PUT /api/campaigns/{id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "advertiser_id": 1,
  "name": "Promoção Especial - Atualizada",
  "start_date": "2024-01-01T00:00:00",
  "end_date": "2024-02-28T23:59:59",
  "status": "ACTIVE"
}
```

### Deletar campanha (Advertiser)

```http
DELETE /api/campaigns/{id}
Authorization: Bearer {token}
```

## 📹 Anúncios

### Criar anúncio (Advertiser)

```http
POST /api/advertisements
Authorization: Bearer {token}
Content-Type: application/json

{
  "campaign_id": 1,
  "title": "Anúncio Especial",
  "description": "Descrição do anúncio",
  "media_type": "video",
  "duration": 30
}
```

### Fazer upload de arquivo

```http
POST /api/advertisements/upload?advertisement_id={id}
Authorization: Bearer {token}
Content-Type: multipart/form-data

file: [arquivo de vídeo/imagem]
```

### Listar anúncios

```http
GET /api/advertisements
Authorization: Bearer {token}
```

### Obter anúncio por ID

```http
GET /api/advertisements/{id}
Authorization: Bearer {token}
```

### Baixar arquivo de anúncio

```http
GET /api/advertisements/download/{id}
Authorization: Bearer {token}
```

### Deletar anúncio (Admin)

```http
DELETE /api/advertisements/{id}
Authorization: Bearer {token}
```

## 📊 Estatísticas

### Dashboard geral

```http
GET /api/statistics/dashboard
Authorization: Bearer {token}
```

**Response:**
```json
{
  "total_advertisers": 5,
  "total_establishments": 10,
  "total_devices": 25,
  "devices_online": 20,
  "devices_offline": 5,
  "active_campaigns": 8,
  "active_advertisements": 15,
  "total_impressions": 1250
}
```

### Impressões por dia

```http
GET /api/statistics/impressions/by-day
Authorization: Bearer {token}
```

### Impressões por anúncio

```http
GET /api/statistics/impressions/by-advertisement
Authorization: Bearer {token}
```

### Impressões por dispositivo

```http
GET /api/statistics/impressions/by-device
Authorization: Bearer {token}
```

### Impressões por estabelecimento

```http
GET /api/statistics/impressions/by-establishment
Authorization: Bearer {token}
```

### Status dos dispositivos

```http
GET /api/statistics/devices/status
Authorization: Bearer {token}
```

## 👨‍💼 Anunciantes

### Criar anunciante (Admin)

```http
POST /api/advertisers
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Empresa XYZ",
  "company_name": "XYZ Ltda",
  "email": "contato@xyz.com",
  "phone": "1133334444"
}
```

### Listar anunciantes

```http
GET /api/advertisers
Authorization: Bearer {token}
```

### Obter anunciante por ID

```http
GET /api/advertisers/{id}
Authorization: Bearer {token}
```

### Atualizar anunciante (Admin)

```http
PUT /api/advertisers/{id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Empresa XYZ - Atualizada",
  "company_name": "XYZ Ltda",
  "email": "novo@xyz.com",
  "phone": "1144445555"
}
```

## 📱 Endpoints do Cliente

### Registrar cliente

```http
POST /api/devices/client/register
Content-Type: application/json

{
  "device_uuid": "550e8400-e29b-41d4-a716-446655440000",
  "device_name": "AdScreen-abc123",
  "client_version": "1.0.0"
}
```

### Heartbeat do cliente

```http
POST /api/devices/client/heartbeat
Content-Type: application/json

{
  "device_uuid": "550e8400-e29b-41d4-a716-446655440000",
  "client_version": "1.0.0"
}
```

### Obter anúncios para cliente

```http
GET /api/client/advertisements/{device_uuid}
```

**Response:**
```json
{
  "device_uuid": "550e8400-e29b-41d4-a716-446655440000",
  "advertisements": [
    {
      "id": 1,
      "title": "Anúncio 1",
      "media_type": "video",
      "duration": 30,
      "file_hash": "sha256hash...",
      "file_size": 10485760,
      "priority": 0
    }
  ]
}
```

### Registrar impressão

```http
POST /api/impressions
Content-Type: application/json

{
  "device_uuid": "550e8400-e29b-41d4-a716-446655440000",
  "advertisement_id": 1,
  "started_at": "2024-01-01T10:30:00",
  "finished_at": "2024-01-01T10:30:30",
  "duration_seconds": 30
}
```

## ⚠️ Códigos de Erro

- **200**: OK
- **201**: Created
- **204**: No Content
- **400**: Bad Request
- **401**: Unauthorized
- **403**: Forbidden
- **404**: Not Found
- **413**: Request Entity Too Large
- **500**: Internal Server Error

## 🔑 Perfis e Permissões

| Endpoint | Admin | Advertiser | Operator |
|----------|-------|-----------|----------|
| POST /establishments | ✅ | ❌ | ❌ |
| GET /establishments | ✅ | ✅ | ✅ |
| POST /devices | ✅ | ❌ | ✅ |
| POST /campaigns | ✅ | ✅ | ❌ |
| POST /advertisements | ✅ | ✅ | ❌ |
| GET /statistics | ✅ | ✅ | ✅ |

---

**Última atualização**: Janeiro 2024
