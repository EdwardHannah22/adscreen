import React, { useState, useEffect } from 'react'
import Dashboard from './pages/Dashboard'
import Login from './pages/Login'
import Establishments from './pages/Establishments'
import Devices from './pages/Devices'
import Campaigns from './pages/Campaigns'
import Advertisements from './pages/Advertisements'
import Statistics from './pages/Statistics'

type Page = 'login' | 'dashboard' | 'establishments' | 'devices' | 'campaigns' | 'advertisements' | 'statistics'

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login')
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'))

  useEffect(() => {
    if (token) {
      setCurrentPage('dashboard')
    }
  }, [token])

  const handleLogin = (newToken: string) => {
    setToken(newToken)
    localStorage.setItem('token', newToken)
    setCurrentPage('dashboard')
  }

  const handleLogout = () => {
    setToken(null)
    localStorage.removeItem('token')
    setCurrentPage('login')
  }

  if (!token) {
    return <Login onLogin={handleLogin} />
  }

  return (
    <div style={{ display: 'flex' }}>
      <div className="sidebar">
        <div style={{ padding: '20px', borderBottom: '1px solid #37474f', marginBottom: '20px' }}>
          <h2 style={{ fontSize: '20px', marginBottom: '5px' }}>AdScreen</h2>
          <small>Plataforma de Publicidade</small>
        </div>
        
        <a
          href="#"
          className={`sidebar-item ${currentPage === 'dashboard' ? 'active' : ''}`}
          onClick={(e) => { e.preventDefault(); setCurrentPage('dashboard') }}
        >
          📊 Dashboard
        </a>
        <a
          href="#"
          className={`sidebar-item ${currentPage === 'establishments' ? 'active' : ''}`}
          onClick={(e) => { e.preventDefault(); setCurrentPage('establishments') }}
        >
          🏪 Estabelecimentos
        </a>
        <a
          href="#"
          className={`sidebar-item ${currentPage === 'devices' ? 'active' : ''}`}
          onClick={(e) => { e.preventDefault(); setCurrentPage('devices') }}
        >
          💻 Computadores
        </a>
        <a
          href="#"
          className={`sidebar-item ${currentPage === 'campaigns' ? 'active' : ''}`}
          onClick={(e) => { e.preventDefault(); setCurrentPage('campaigns') }}
        >
          📢 Campanhas
        </a>
        <a
          href="#"
          className={`sidebar-item ${currentPage === 'advertisements' ? 'active' : ''}`}
          onClick={(e) => { e.preventDefault(); setCurrentPage('advertisements') }}
        >
          📹 Anúncios
        </a>
        <a
          href="#"
          className={`sidebar-item ${currentPage === 'statistics' ? 'active' : ''}`}
          onClick={(e) => { e.preventDefault(); setCurrentPage('statistics') }}
        >
          📈 Estatísticas
        </a>
        
        <div style={{ marginTop: '40px', borderTop: '1px solid #37474f', paddingTop: '20px' }}>
          <a
            href="#"
            className="sidebar-item"
            onClick={(e) => { e.preventDefault(); handleLogout() }}
          >
            🚪 Sair
          </a>
        </div>
      </div>

      <div className="main-content">
        <div className="header">
          <h1>
            {currentPage === 'dashboard' && '📊 Dashboard'}
            {currentPage === 'establishments' && '🏪 Estabelecimentos'}
            {currentPage === 'devices' && '💻 Computadores'}
            {currentPage === 'campaigns' && '📢 Campanhas'}
            {currentPage === 'advertisements' && '📹 Anúncios'}
            {currentPage === 'statistics' && '📈 Estatísticas'}
          </h1>
        </div>

        <div className="container">
          {currentPage === 'dashboard' && <Dashboard token={token} />}
          {currentPage === 'establishments' && <Establishments token={token} />}
          {currentPage === 'devices' && <Devices token={token} />}
          {currentPage === 'campaigns' && <Campaigns token={token} />}
          {currentPage === 'advertisements' && <Advertisements token={token} />}
          {currentPage === 'statistics' && <Statistics token={token} />}
        </div>
      </div>
    </div>
  )
}

export default App
