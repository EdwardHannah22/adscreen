import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface CampaignsProps {
  token: string | null
}

interface Campaign {
  id: number
  name: string
  advertiser_id: number
  start_date: string
  end_date: string
  status: string
}

export default function Campaigns({ token }: CampaignsProps) {
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    advertiser_id: 1,
    start_date: '',
    end_date: '',
    status: 'DRAFT'
  })

  useEffect(() => {
    fetchCampaigns()
  }, [token])

  const fetchCampaigns = async () => {
    try {
      const response = await axios.get('/api/campaigns', {
        headers: { Authorization: `Bearer ${token}` }
      })
      setCampaigns(response.data)
    } catch (error) {
      console.error('Erro ao carregar campanhas:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await axios.post('/api/campaigns', formData, {
        headers: { Authorization: `Bearer ${token}` }
      })
      fetchCampaigns()
      setShowForm(false)
      setFormData({
        name: '',
        advertiser_id: 1,
        start_date: '',
        end_date: '',
        status: 'DRAFT'
      })
    } catch (error) {
      console.error('Erro ao criar campanha:', error)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('pt-BR')
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ACTIVE':
        return 'status-active'
      case 'DRAFT':
        return 'status-draft'
      case 'PAUSED':
        return 'status-inactive'
      case 'COMPLETED':
        return 'status-offline'
      default:
        return 'status-draft'
    }
  }

  if (loading) {
    return <div className="loading">Carregando...</div>
  }

  return (
    <div>
      <div style={{ marginBottom: '20px' }}>
        <button
          className="btn"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? 'Cancelar' : '➕ Nova Campanha'}
        </button>
      </div>

      {showForm && (
        <div className="form" style={{ marginBottom: '20px' }}>
          <h3 style={{ marginBottom: '20px' }}>Nova Campanha</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Nome</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Data Inicial</label>
              <input
                type="datetime-local"
                value={formData.start_date}
                onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Data Final</label>
              <input
                type="datetime-local"
                value={formData.end_date}
                onChange={(e) => setFormData({ ...formData, end_date: e.target.value })}
                required
              />
            </div>
            <button type="submit" className="btn">Criar Campanha</button>
          </form>
        </div>
      )}

      <div className="card">
        {campaigns.length === 0 ? (
          <p style={{ color: '#666' }}>Nenhuma campanha cadastrada</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Data Inicial</th>
                <th>Data Final</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {campaigns.map((campaign) => (
                <tr key={campaign.id}>
                  <td><strong>{campaign.name}</strong></td>
                  <td>{formatDate(campaign.start_date)}</td>
                  <td>{formatDate(campaign.end_date)}</td>
                  <td>
                    <span className={`status-badge ${getStatusColor(campaign.status)}`}>
                      {campaign.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
