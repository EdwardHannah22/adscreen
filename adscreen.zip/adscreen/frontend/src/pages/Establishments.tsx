import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface EstablishmentsProps {
  token: string | null
}

interface Establishment {
  id: number
  name: string
  address: string
  city: string
  state: string
  status: string
}

export default function Establishments({ token }: EstablishmentsProps) {
  const [establishments, setEstablishments] = useState<Establishment[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    state: ''
  })

  useEffect(() => {
    fetchEstablishments()
  }, [token])

  const fetchEstablishments = async () => {
    try {
      const response = await axios.get('/api/establishments', {
        headers: { Authorization: `Bearer ${token}` }
      })
      setEstablishments(response.data)
    } catch (error) {
      console.error('Erro ao carregar estabelecimentos:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await axios.post('/api/establishments', formData, {
        headers: { Authorization: `Bearer ${token}` }
      })
      fetchEstablishments()
      setShowForm(false)
      setFormData({ name: '', address: '', city: '', state: '' })
    } catch (error) {
      console.error('Erro ao criar estabelecimento:', error)
    }
  }

  if (loading) {
    return <div className="loading">Carregando...</div>
  }

  return (
    <div>
      <div style={{ marginBottom: '20px' }}>
        <button
          className="btn"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? 'Cancelar' : '➕ Novo Estabelecimento'}
        </button>
      </div>

      {showForm && (
        <div className="form" style={{ marginBottom: '20px' }}>
          <h3 style={{ marginBottom: '20px' }}>Novo Estabelecimento</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Nome</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Endereço</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Cidade</label>
              <input
                type="text"
                value={formData.city}
                onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Estado</label>
              <input
                type="text"
                value={formData.state}
                onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                required
                placeholder="SP, RJ, MG..."
              />
            </div>
            <button type="submit" className="btn">Criar Estabelecimento</button>
          </form>
        </div>
      )}

      <div className="card">
        {establishments.length === 0 ? (
          <p style={{ color: '#666' }}>Nenhum estabelecimento cadastrado</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>Endereço</th>
                <th>Cidade</th>
                <th>Estado</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {establishments.map((est) => (
                <tr key={est.id}>
                  <td><strong>{est.name}</strong></td>
                  <td>{est.address}</td>
                  <td>{est.city}</td>
                  <td>{est.state}</td>
                  <td>
                    <span className="status-badge status-active">
                      {est.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
