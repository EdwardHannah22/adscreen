import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface DashboardProps {
  token: string | null
}

interface Statistics {
  total_advertisers: number
  total_establishments: number
  total_devices: number
  devices_online: number
  devices_offline: number
  active_campaigns: number
  active_advertisements: number
  total_impressions: number
}

export default function Dashboard({ token }: DashboardProps) {
  const [stats, setStats] = useState<Statistics | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStatistics()
  }, [token])

  const fetchStatistics = async () => {
    try {
      const response = await axios.get('/api/statistics/dashboard', {
        headers: { Authorization: `Bearer ${token}` }
      })
      setStats(response.data)
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="loading">Carregando...</div>
  }

  return (
    <div>
      <div className="dashboard-grid">
        <div className="card">
          <h3>Total de Anunciantes</h3>
          <div className="value">{stats?.total_advertisers || 0}</div>
        </div>

        <div className="card">
          <h3>Total de Estabelecimentos</h3>
          <div className="value">{stats?.total_establishments || 0}</div>
        </div>

        <div className="card">
          <h3>Total de Computadores</h3>
          <div className="value">{stats?.total_devices || 0}</div>
        </div>

        <div className="card">
          <h3>Computadores Online</h3>
          <div className="value" style={{ color: '#2e7d32' }}>
            {stats?.devices_online || 0}
          </div>
        </div>

        <div className="card">
          <h3>Computadores Offline</h3>
          <div className="value" style={{ color: '#c62828' }}>
            {stats?.devices_offline || 0}
          </div>
        </div>

        <div className="card">
          <h3>Campanhas Ativas</h3>
          <div className="value">{stats?.active_campaigns || 0}</div>
        </div>

        <div className="card">
          <h3>Anúncios Ativos</h3>
          <div className="value">{stats?.active_advertisements || 0}</div>
        </div>

        <div className="card">
          <h3>Total de Impressões</h3>
          <div className="value">{stats?.total_impressions || 0}</div>
        </div>
      </div>

      <div className="card" style={{ marginTop: '30px' }}>
        <h2 style={{ marginBottom: '20px' }}>Bem-vindo ao AdScreen!</h2>
        <p style={{ color: '#666', lineHeight: '1.6' }}>
          AdScreen é uma plataforma completa de publicidade digital que permite você gerenciar
          anúncios em computadores instalados em estabelecimentos comerciais.
        </p>
        <p style={{ marginTop: '15px', color: '#666', lineHeight: '1.6' }}>
          Use o menu lateral para navegar e gerenciar:
        </p>
        <ul style={{ marginTop: '10px', marginLeft: '20px', color: '#666' }}>
          <li>📍 Estabelecimentos e seus computadores</li>
          <li>💻 Status e configurações dos dispositivos</li>
          <li>📢 Campanhas publicitárias</li>
          <li>📹 Upload e gerenciamento de vídeos</li>
          <li>📊 Estatísticas e análises</li>
        </ul>
      </div>
    </div>
  )
}
