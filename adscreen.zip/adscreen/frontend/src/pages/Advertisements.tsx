import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface AdvertisementsProps {
  token: string | null
}

interface Advertisement {
  id: number
  title: string
  campaign_id: number
  media_type: string
  duration: number
  file_size: number | null
  active: boolean
}

export default function Advertisements({ token }: AdvertisementsProps) {
  const [advertisements, setAdvertisements] = useState<Advertisement[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    title: '',
    campaign_id: 1,
    media_type: 'video',
    duration: 30
  })
  const [file, setFile] = useState<File | null>(null)

  useEffect(() => {
    fetchAdvertisements()
  }, [token])

  const fetchAdvertisements = async () => {
    try {
      const response = await axios.get('/api/advertisements', {
        headers: { Authorization: `Bearer ${token}` }
      })
      setAdvertisements(response.data)
    } catch (error) {
      console.error('Erro ao carregar anúncios:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      // Criar anúncio
      const response = await axios.post('/api/advertisements', formData, {
        headers: { Authorization: `Bearer ${token}` }
      })

      // Se tem arquivo, fazer upload
      if (file) {
        const formDataFile = new FormData()
        formDataFile.append('file', file)

        await axios.post(
          `/api/advertisements/upload?advertisement_id=${response.data.id}`,
          formDataFile,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              'Content-Type': 'multipart/form-data'
            }
          }
        )
      }

      fetchAdvertisements()
      setShowForm(false)
      setFormData({
        title: '',
        campaign_id: 1,
        media_type: 'video',
        duration: 30
      })
      setFile(null)
    } catch (error) {
      console.error('Erro ao criar anúncio:', error)
    }
  }

  const formatFileSize = (bytes: number | null) => {
    if (!bytes) return '-'
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB'
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB'
  }

  if (loading) {
    return <div className="loading">Carregando...</div>
  }

  return (
    <div>
      <div style={{ marginBottom: '20px' }}>
        <button
          className="btn"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? 'Cancelar' : '➕ Novo Anúncio'}
        </button>
      </div>

      {showForm && (
        <div className="form" style={{ marginBottom: '20px' }}>
          <h3 style={{ marginBottom: '20px' }}>Novo Anúncio</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Título</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label>Tipo de Mídia</label>
              <select
                value={formData.media_type}
                onChange={(e) => setFormData({ ...formData, media_type: e.target.value })}
              >
                <option value="video">Vídeo</option>
                <option value="image">Imagem</option>
              </select>
            </div>
            <div className="form-group">
              <label>Duração (segundos)</label>
              <input
                type="number"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) })}
                min="1"
                required
              />
            </div>
            <div className="form-group">
              <label>Arquivo</label>
              <input
                type="file"
                onChange={(e) => setFile(e.target.files?.[0] || null)}
                accept="video/mp4,video/webm,image/png,image/jpeg,image/gif"
              />
            </div>
            <button type="submit" className="btn">Criar Anúncio</button>
          </form>
        </div>
      )}

      <div className="card">
        {advertisements.length === 0 ? (
          <p style={{ color: '#666' }}>Nenhum anúncio cadastrado</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Título</th>
                <th>Tipo</th>
                <th>Duração</th>
                <th>Tamanho</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {advertisements.map((ad) => (
                <tr key={ad.id}>
                  <td><strong>{ad.title}</strong></td>
                  <td>
                    {ad.media_type === 'video' ? '📹' : '🖼️'} {ad.media_type}
                  </td>
                  <td>{ad.duration}s</td>
                  <td>{formatFileSize(ad.file_size)}</td>
                  <td>
                    <span className={`status-badge ${ad.active ? 'status-active' : 'status-offline'}`}>
                      {ad.active ? 'Ativo' : 'Inativo'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
