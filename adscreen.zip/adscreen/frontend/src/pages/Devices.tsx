import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface DevicesProps {
  token: string | null
}

interface Device {
  id: number
  name: string
  device_uuid: string
  status: string
  last_seen: string | null
  client_version: string | null
}

export default function Devices({ token }: DevicesProps) {
  const [devices, setDevices] = useState<Device[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDevices()
    const interval = setInterval(fetchDevices, 5000) // Atualizar a cada 5 segundos
    return () => clearInterval(interval)
  }, [token])

  const fetchDevices = async () => {
    try {
      const response = await axios.get('/api/devices', {
        headers: { Authorization: `Bearer ${token}` }
      })
      setDevices(response.data)
    } catch (error) {
      console.error('Erro ao carregar dispositivos:', error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ONLINE':
        return 'status-online'
      case 'OFFLINE':
        return 'status-offline'
      case 'INACTIVE':
        return 'status-inactive'
      default:
        return 'status-offline'
    }
  }

  const formatDate = (dateString: string | null) => {
    if (!dateString) return '-'
    const date = new Date(dateString)
    return date.toLocaleDateString('pt-BR') + ' ' + date.toLocaleTimeString('pt-BR')
  }

  if (loading) {
    return <div className="loading">Carregando...</div>
  }

  return (
    <div>
      <div className="card">
        <div style={{ marginBottom: '20px' }}>
          <p style={{ color: '#666' }}>
            Total de computadores: <strong>{devices.length}</strong>
          </p>
        </div>

        {devices.length === 0 ? (
          <p style={{ color: '#666' }}>Nenhum computador registrado</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Nome</th>
                <th>UUID</th>
                <th>Status</th>
                <th>Última Atividade</th>
                <th>Versão do Cliente</th>
              </tr>
            </thead>
            <tbody>
              {devices.map((device) => (
                <tr key={device.id}>
                  <td><strong>{device.name}</strong></td>
                  <td style={{ fontSize: '12px', fontFamily: 'monospace' }}>
                    {device.device_uuid.substring(0, 8)}...
                  </td>
                  <td>
                    <span className={`status-badge ${getStatusColor(device.status)}`}>
                      {device.status}
                    </span>
                  </td>
                  <td style={{ fontSize: '12px' }}>
                    {formatDate(device.last_seen)}
                  </td>
                  <td>{device.client_version || '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
