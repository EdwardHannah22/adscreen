import React, { useState, useEffect } from 'react'
import axios from 'axios'

interface StatisticsProps {
  token: string | null
}

export default function Statistics({ token }: StatisticsProps) {
  const [impressionsByDay, setImpressionsByDay] = useState<any[]>([])
  const [impressionsByAd, setImpressionsByAd] = useState<any[]>([])
  const [deviceStatus, setDeviceStatus] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchStatistics()
  }, [token])

  const fetchStatistics = async () => {
    try {
      const [byDay, byAd, status] = await Promise.all([
        axios.get('/api/statistics/impressions/by-day', {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get('/api/statistics/impressions/by-advertisement', {
          headers: { Authorization: `Bearer ${token}` }
        }),
        axios.get('/api/statistics/devices/status', {
          headers: { Authorization: `Bearer ${token}` }
        })
      ])

      setImpressionsByDay(byDay.data)
      setImpressionsByAd(byAd.data)
      setDeviceStatus(status.data)
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="loading">Carregando...</div>
  }

  return (
    <div>
      <div className="card" style={{ marginBottom: '20px' }}>
        <h3 style={{ marginBottom: '15px' }}>Impressões por Dia (Últimos 30 dias)</h3>
        {impressionsByDay.length === 0 ? (
          <p style={{ color: '#666' }}>Sem dados</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Data</th>
                <th>Total de Impressões</th>
              </tr>
            </thead>
            <tbody>
              {impressionsByDay.map((item: any, idx: number) => (
                <tr key={idx}>
                  <td>{item.day}</td>
                  <td><strong>{item.count}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card" style={{ marginBottom: '20px' }}>
        <h3 style={{ marginBottom: '15px' }}>Impressões por Anúncio</h3>
        {impressionsByAd.length === 0 ? (
          <p style={{ color: '#666' }}>Sem dados</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Anúncio</th>
                <th>Total de Impressões</th>
              </tr>
            </thead>
            <tbody>
              {impressionsByAd.map((item: any, idx: number) => (
                <tr key={idx}>
                  <td>{item.title}</td>
                  <td><strong>{item.count}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="card">
        <h3 style={{ marginBottom: '15px' }}>Status dos Dispositivos</h3>
        {deviceStatus.length === 0 ? (
          <p style={{ color: '#666' }}>Sem dados</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th>Status</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>
              {deviceStatus.map((item: any, idx: number) => (
                <tr key={idx}>
                  <td>
                    <span className={`status-badge status-${item.status.toLowerCase()}`}>
                      {item.status}
                    </span>
                  </td>
                  <td><strong>{item.count}</strong></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
