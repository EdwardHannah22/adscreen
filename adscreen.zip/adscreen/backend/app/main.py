from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from app.database import init_db
from app.config import get_settings
from app.routers import auth, users, advertisers, establishments, devices, campaigns, advertisements, statistics
import os

settings = get_settings()

# Inicializar banco de dados
init_db()

# Criar app FastAPI
app = FastAPI(
    title="AdScreen API",
    description="API de publicidade digital AdScreen",
    version="1.0.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir routers
app.include_router(auth.router)
app.include_router(users.router)
app.include_router(advertisers.router)
app.include_router(establishments.router)
app.include_router(devices.router)
app.include_router(campaigns.router)
app.include_router(advertisements.router)
app.include_router(statistics.router)


@app.get("/")
def read_root():
    """Health check"""
    return {
        "status": "ok",
        "application": "AdScreen API",
        "version": "1.0.0"
    }


@app.get("/health")
def health_check():
    """Health check"""
    return {"status": "healthy"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
