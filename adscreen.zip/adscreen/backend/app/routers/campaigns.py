from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User, Campaign, Advertiser, UserRole
from app.schemas import CampaignCreate, CampaignResponse
from app.auth import get_current_user, get_advertiser_user, get_admin_user

router = APIRouter(prefix="/api/campaigns", tags=["campaigns"])


@router.post("", response_model=CampaignResponse)
def create_campaign(
    campaign_data: CampaignCreate,
    current_user: User = Depends(get_advertiser_user),
    db: Session = Depends(get_db)
):
    """Criar nova campanha"""
    
    # Verificar se advertiser existe
    advertiser = db.query(Advertiser).filter(
        Advertiser.id == campaign_data.advertiser_id
    ).first()
    
    if not advertiser:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertiser not found"
        )
    
    # Apenas admin ou o próprio anunciante pode criar
    if (current_user.role != UserRole.ADMIN and 
        advertiser.user_id != current_user.id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    db_campaign = Campaign(
        advertiser_id=campaign_data.advertiser_id,
        name=campaign_data.name,
        description=campaign_data.description,
        start_date=campaign_data.start_date,
        end_date=campaign_data.end_date,
        status=campaign_data.status,
        budget=campaign_data.budget
    )
    
    db.add(db_campaign)
    db.commit()
    db.refresh(db_campaign)
    
    return db_campaign


@router.get("", response_model=list[CampaignResponse])
def list_campaigns(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar todas as campanhas"""
    campaigns = db.query(Campaign).all()
    return campaigns


@router.get("/{campaign_id}", response_model=CampaignResponse)
def get_campaign(
    campaign_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter campanha por ID"""
    
    campaign = db.query(Campaign).filter(Campaign.id == campaign_id).first()
    
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
    
    return campaign


@router.put("/{campaign_id}", response_model=CampaignResponse)
def update_campaign(
    campaign_id: int,
    campaign_data: CampaignCreate,
    current_user: User = Depends(get_advertiser_user),
    db: Session = Depends(get_db)
):
    """Atualizar campanha"""
    
    campaign = db.query(Campaign).filter(Campaign.id == campaign_id).first()
    
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
    
    # Verificar permissões
    advertiser = db.query(Advertiser).filter(
        Advertiser.id == campaign.advertiser_id
    ).first()
    
    if (current_user.role != UserRole.ADMIN and 
        advertiser.user_id != current_user.id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    campaign.name = campaign_data.name
    campaign.description = campaign_data.description
    campaign.start_date = campaign_data.start_date
    campaign.end_date = campaign_data.end_date
    campaign.status = campaign_data.status
    campaign.budget = campaign_data.budget
    
    db.commit()
    db.refresh(campaign)
    
    return campaign


@router.delete("/{campaign_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_campaign(
    campaign_id: int,
    current_user: User = Depends(get_advertiser_user),
    db: Session = Depends(get_db)
):
    """Deletar campanha"""
    
    campaign = db.query(Campaign).filter(Campaign.id == campaign_id).first()
    
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
    
    # Verificar permissões
    advertiser = db.query(Advertiser).filter(
        Advertiser.id == campaign.advertiser_id
    ).first()
    
    if (current_user.role != UserRole.ADMIN and 
        advertiser.user_id != current_user.id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    db.delete(campaign)
    db.commit()
