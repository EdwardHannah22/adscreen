from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.database import get_db
from app.models import (
    User, Advertiser, Establishment, Device, Campaign, Advertisement,
    Impression, DeviceStatus, CampaignStatus
)
from app.schemas import StatisticsResponse
from app.auth import get_current_user

router = APIRouter(prefix="/api/statistics", tags=["statistics"])


@router.get("/dashboard", response_model=StatisticsResponse)
def get_dashboard_statistics(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter estatísticas do dashboard"""
    
    total_advertisers = db.query(Advertiser).count()
    total_establishments = db.query(Establishment).count()
    total_devices = db.query(Device).count()
    devices_online = db.query(Device).filter(Device.status == DeviceStatus.ONLINE).count()
    devices_offline = total_devices - devices_online
    active_campaigns = db.query(Campaign).filter(
        Campaign.status == CampaignStatus.ACTIVE
    ).count()
    active_advertisements = db.query(Advertisement).filter(
        Advertisement.active == True
    ).count()
    total_impressions = db.query(Impression).count()
    
    return StatisticsResponse(
        total_advertisers=total_advertisers,
        total_establishments=total_establishments,
        total_devices=total_devices,
        devices_online=devices_online,
        devices_offline=devices_offline,
        active_campaigns=active_campaigns,
        active_advertisements=active_advertisements,
        total_impressions=total_impressions
    )


@router.get("/impressions/by-day")
def get_impressions_by_day(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Impressões por dia (últimos 30 dias)"""
    from datetime import datetime, timedelta
    
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    
    impressions = db.query(
        func.date(Impression.started_at).label("day"),
        func.count(Impression.id).label("count")
    ).filter(
        Impression.started_at >= thirty_days_ago
    ).group_by(
        func.date(Impression.started_at)
    ).all()
    
    return [
        {"day": str(imp.day), "count": imp.count}
        for imp in impressions
    ]


@router.get("/impressions/by-advertisement")
def get_impressions_by_advertisement(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Impressões por anúncio"""
    
    impressions = db.query(
        Advertisement.title,
        func.count(Impression.id).label("count")
    ).join(
        Impression, Impression.advertisement_id == Advertisement.id
    ).group_by(
        Advertisement.title
    ).all()
    
    return [
        {"title": imp.title, "count": imp.count}
        for imp in impressions
    ]


@router.get("/impressions/by-device")
def get_impressions_by_device(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Impressões por dispositivo"""
    
    impressions = db.query(
        Device.name,
        func.count(Impression.id).label("count")
    ).join(
        Impression, Impression.device_id == Device.id
    ).group_by(
        Device.name
    ).all()
    
    return [
        {"device": imp.name, "count": imp.count}
        for imp in impressions
    ]


@router.get("/impressions/by-establishment")
def get_impressions_by_establishment(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Impressões por estabelecimento"""
    
    impressions = db.query(
        Establishment.name,
        func.count(Impression.id).label("count")
    ).join(
        Device, Device.establishment_id == Establishment.id
    ).join(
        Impression, Impression.device_id == Device.id
    ).group_by(
        Establishment.name
    ).all()
    
    return [
        {"establishment": imp.name, "count": imp.count}
        for imp in impressions
    ]


@router.get("/devices/status")
def get_devices_status(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Status dos dispositivos"""
    
    status_counts = db.query(
        Device.status,
        func.count(Device.id).label("count")
    ).group_by(
        Device.status
    ).all()
    
    return [
        {"status": str(s.status), "count": s.count}
        for s in status_counts
    ]
