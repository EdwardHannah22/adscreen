from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session
import os
import hashlib
from datetime import datetime
from app.database import get_db
from app.models import User, Advertisement, Campaign, Device, Impression, DeviceStatus
from app.schemas import (
    AdvertisementCreate, AdvertisementResponse, ImpressionCreate, ImpressionResponse
)
from app.auth import get_current_user, get_advertiser_user, get_admin_user
from app.config import get_settings

settings = get_settings()
router = APIRouter(prefix="/api", tags=["advertisements"])


def ensure_storage_dirs():
    """Garantir que os diretórios de storage existem"""
    storage_path = settings.storage_path
    os.makedirs(storage_path, exist_ok=True)
    os.makedirs(os.path.join(storage_path, "advertisers"), exist_ok=True)
    os.makedirs(os.path.join(storage_path, "campaigns"), exist_ok=True)
    os.makedirs(os.path.join(storage_path, "advertisements"), exist_ok=True)


@router.post("/advertisements", response_model=AdvertisementResponse)
def create_advertisement(
    advertisement_data: AdvertisementCreate,
    current_user: User = Depends(get_advertiser_user),
    db: Session = Depends(get_db)
):
    """Criar novo anúncio"""
    
    campaign = db.query(Campaign).filter(Campaign.id == advertisement_data.campaign_id).first()
    
    if not campaign:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Campaign not found"
        )
    
    db_advertisement = Advertisement(
        campaign_id=advertisement_data.campaign_id,
        title=advertisement_data.title,
        description=advertisement_data.description,
        media_type=advertisement_data.media_type,
        duration=advertisement_data.duration,
        media_path="",  # Será preenchido no upload
        active=True
    )
    
    db.add(db_advertisement)
    db.commit()
    db.refresh(db_advertisement)
    
    return db_advertisement


@router.post("/advertisements/upload")
async def upload_advertisement_file(
    advertisement_id: int,
    file: UploadFile = File(...),
    current_user: User = Depends(get_advertiser_user),
    db: Session = Depends(get_db)
):
    """Upload de arquivo de anúncio"""
    
    ensure_storage_dirs()
    
    advertisement = db.query(Advertisement).filter(
        Advertisement.id == advertisement_id
    ).first()
    
    if not advertisement:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertisement not found"
        )
    
    # Validar tipo de arquivo
    allowed_extensions = {"mp4", "webm", "png", "jpg", "jpeg", "gif"}
    file_ext = file.filename.split(".")[-1].lower()
    
    if file_ext not in allowed_extensions:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"File type not allowed. Allowed: {allowed_extensions}"
        )
    
    # Validar tamanho (máx 500MB)
    max_size = 500 * 1024 * 1024
    content = await file.read()
    
    if len(content) > max_size:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="File too large"
        )
    
    # Calcular hash do arquivo
    file_hash = hashlib.sha256(content).hexdigest()
    
    # Salvar arquivo
    storage_path = settings.storage_path
    file_path = os.path.join(storage_path, "advertisements", f"{file_hash}.{file_ext}")
    
    with open(file_path, "wb") as f:
        f.write(content)
    
    # Atualizar anúncio
    advertisement.media_path = file_path
    advertisement.file_hash = file_hash
    advertisement.file_size = len(content)
    
    db.commit()
    db.refresh(advertisement)
    
    return {
        "advertisement_id": advertisement.id,
        "file_hash": file_hash,
        "file_size": len(content),
        "uploaded_at": datetime.utcnow()
    }


@router.get("/advertisements", response_model=list[AdvertisementResponse])
def list_advertisements(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar todos os anúncios"""
    advertisements = db.query(Advertisement).filter(Advertisement.active == True).all()
    return advertisements


@router.get("/advertisements/{advertisement_id}", response_model=AdvertisementResponse)
def get_advertisement(
    advertisement_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter anúncio por ID"""
    
    advertisement = db.query(Advertisement).filter(
        Advertisement.id == advertisement_id
    ).first()
    
    if not advertisement:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertisement not found"
        )
    
    return advertisement


@router.get("/advertisements/download/{advertisement_id}")
def download_advertisement(
    advertisement_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Download de arquivo de anúncio (para client)"""
    
    advertisement = db.query(Advertisement).filter(
        Advertisement.id == advertisement_id
    ).first()
    
    if not advertisement or not advertisement.media_path:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertisement not found"
        )
    
    if not os.path.exists(advertisement.media_path):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="File not found"
        )
    
    return FileResponse(
        advertisement.media_path,
        filename=os.path.basename(advertisement.media_path)
    )


@router.delete("/advertisements/{advertisement_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_advertisement(
    advertisement_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar anúncio"""
    
    advertisement = db.query(Advertisement).filter(
        Advertisement.id == advertisement_id
    ).first()
    
    if not advertisement:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertisement not found"
        )
    
    # Deletar arquivo
    if advertisement.media_path and os.path.exists(advertisement.media_path):
        os.remove(advertisement.media_path)
    
    db.delete(advertisement)
    db.commit()


# Impressions
@router.post("/impressions", response_model=ImpressionResponse)
def create_impression(
    impression_data: ImpressionCreate,
    db: Session = Depends(get_db)
):
    """Registrar impressão (usado pelo client)"""
    
    # Buscar device pelo UUID
    device = db.query(Device).filter(
        Device.device_uuid == impression_data.device_uuid
    ).first()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Verificar se advertisement existe
    advertisement = db.query(Advertisement).filter(
        Advertisement.id == impression_data.advertisement_id
    ).first()
    
    if not advertisement:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertisement not found"
        )
    
    db_impression = Impression(
        device_id=device.id,
        advertisement_id=advertisement.id,
        started_at=impression_data.started_at,
        finished_at=impression_data.finished_at,
        duration_seconds=impression_data.duration_seconds
    )
    
    db.add(db_impression)
    db.commit()
    db.refresh(db_impression)
    
    return db_impression


@router.get("/impressions", response_model=list[ImpressionResponse])
def list_impressions(
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Listar todas as impressões"""
    impressions = db.query(Impression).all()
    return impressions


@router.get("/client/advertisements/{device_uuid}")
def get_client_advertisements(
    device_uuid: str,
    db: Session = Depends(get_db)
):
    """Obter anúncios para um cliente específico"""
    
    device = db.query(Device).filter(Device.device_uuid == device_uuid).first()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Buscar anúncios associados ao dispositivo
    from app.models import DeviceAdvertisement
    
    device_advertisements = db.query(DeviceAdvertisement).filter(
        DeviceAdvertisement.device_id == device.id,
        DeviceAdvertisement.active == True
    ).all()
    
    advertisements = []
    for da in device_advertisements:
        ad = da.advertisement
        advertisements.append({
            "id": ad.id,
            "title": ad.title,
            "media_type": ad.media_type,
            "duration": ad.duration,
            "file_hash": ad.file_hash,
            "file_size": ad.file_size,
            "priority": da.priority
        })
    
    return {
        "device_uuid": device_uuid,
        "advertisements": advertisements
    }
