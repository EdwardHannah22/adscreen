from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User, Establishment
from app.schemas import EstablishmentCreate, EstablishmentResponse
from app.auth import get_current_user, get_admin_user, get_advertiser_user

router = APIRouter(prefix="/api/establishments", tags=["establishments"])


@router.post("", response_model=EstablishmentResponse)
def create_establishment(
    establishment_data: EstablishmentCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar novo estabelecimento (apenas admin)"""
    
    db_establishment = Establishment(
        name=establishment_data.name,
        address=establishment_data.address,
        city=establishment_data.city,
        state=establishment_data.state,
        latitude=establishment_data.latitude,
        longitude=establishment_data.longitude
    )
    
    db.add(db_establishment)
    db.commit()
    db.refresh(db_establishment)
    
    return db_establishment


@router.get("", response_model=list[EstablishmentResponse])
def list_establishments(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar todos os estabelecimentos"""
    establishments = db.query(Establishment).all()
    return establishments


@router.get("/{establishment_id}", response_model=EstablishmentResponse)
def get_establishment(
    establishment_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter estabelecimento por ID"""
    
    establishment = db.query(Establishment).filter(
        Establishment.id == establishment_id
    ).first()
    
    if not establishment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Establishment not found"
        )
    
    return establishment


@router.put("/{establishment_id}", response_model=EstablishmentResponse)
def update_establishment(
    establishment_id: int,
    establishment_data: EstablishmentCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar estabelecimento (apenas admin)"""
    
    establishment = db.query(Establishment).filter(
        Establishment.id == establishment_id
    ).first()
    
    if not establishment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Establishment not found"
        )
    
    establishment.name = establishment_data.name
    establishment.address = establishment_data.address
    establishment.city = establishment_data.city
    establishment.state = establishment_data.state
    establishment.latitude = establishment_data.latitude
    establishment.longitude = establishment_data.longitude
    
    db.commit()
    db.refresh(establishment)
    
    return establishment


@router.delete("/{establishment_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_establishment(
    establishment_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar estabelecimento (apenas admin)"""
    
    establishment = db.query(Establishment).filter(
        Establishment.id == establishment_id
    ).first()
    
    if not establishment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Establishment not found"
        )
    
    db.delete(establishment)
    db.commit()
