from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from datetime import datetime
from app.database import get_db
from app.models import User, Device, DeviceStatus
from app.schemas import DeviceCreate, DeviceResponse, DeviceRegistrationRequest, DeviceHeartbeatRequest
from app.auth import get_current_user, get_admin_user

router = APIRouter(prefix="/api/devices", tags=["devices"])


@router.post("", response_model=DeviceResponse)
def create_device(
    device_data: DeviceCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar novo dispositivo (apenas admin)"""
    
    import uuid
    
    db_device = Device(
        name=device_data.name,
        device_uuid=str(uuid.uuid4()),
        establishment_id=device_data.establishment_id,
        status=DeviceStatus.OFFLINE
    )
    
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    
    return db_device


@router.get("", response_model=list[DeviceResponse])
def list_devices(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar todos os dispositivos"""
    devices = db.query(Device).all()
    return devices


@router.get("/{device_id}", response_model=DeviceResponse)
def get_device(
    device_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter dispositivo por ID"""
    
    device = db.query(Device).filter(Device.id == device_id).first()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    return device


@router.put("/{device_id}", response_model=DeviceResponse)
def update_device(
    device_id: int,
    device_data: DeviceCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar dispositivo (apenas admin)"""
    
    device = db.query(Device).filter(Device.id == device_id).first()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    device.name = device_data.name
    device.establishment_id = device_data.establishment_id
    
    db.commit()
    db.refresh(device)
    
    return device


@router.delete("/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_device(
    device_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar dispositivo (apenas admin)"""
    
    device = db.query(Device).filter(Device.id == device_id).first()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    db.delete(device)
    db.commit()


# Endpoints para o client
@router.post("/client/register")
def register_device(
    registration_data: DeviceRegistrationRequest,
    db: Session = Depends(get_db)
):
    """Registrar cliente (usado pelo client.exe)"""
    
    # Verificar se dispositivo já existe
    existing_device = db.query(Device).filter(
        Device.device_uuid == registration_data.device_uuid
    ).first()
    
    if existing_device:
        existing_device.client_version = registration_data.client_version
        existing_device.last_seen = datetime.utcnow()
        existing_device.status = DeviceStatus.ONLINE
        db.commit()
        db.refresh(existing_device)
        return {
            "status": "registered",
            "device_id": existing_device.id,
            "device_uuid": existing_device.device_uuid
        }
    
    # Criar novo dispositivo sem establishment
    # O admin pode vincular depois
    db_device = Device(
        name=f"Device-{registration_data.device_uuid[:8]}",
        device_uuid=registration_data.device_uuid,
        establishment_id=1,  # Padrão, será vinculado depois
        status=DeviceStatus.ONLINE,
        client_version=registration_data.client_version,
        last_seen=datetime.utcnow()
    )
    
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    
    return {
        "status": "registered",
        "device_id": db_device.id,
        "device_uuid": db_device.device_uuid
    }


@router.post("/client/heartbeat")
def device_heartbeat(
    heartbeat_data: DeviceHeartbeatRequest,
    db: Session = Depends(get_db)
):
    """Heartbeat do cliente (usado pelo client.exe)"""
    
    device = db.query(Device).filter(
        Device.device_uuid == heartbeat_data.device_uuid
    ).first()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    device.last_seen = datetime.utcnow()
    device.status = DeviceStatus.ONLINE
    device.client_version = heartbeat_data.client_version
    
    db.commit()
    
    return {"status": "ok"}
