from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import User, Advertiser, UserRole
from app.schemas import AdvertiserCreate, AdvertiserResponse
from app.auth import get_current_user, get_admin_user

router = APIRouter(prefix="/api/advertisers", tags=["advertisers"])


@router.post("", response_model=AdvertiserResponse)
def create_advertiser(
    advertiser_data: AdvertiserCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar novo anunciante (apenas admin)"""
    
    db_advertiser = Advertiser(
        name=advertiser_data.name,
        company_name=advertiser_data.company_name,
        email=advertiser_data.email,
        phone=advertiser_data.phone
    )
    
    db.add(db_advertiser)
    db.commit()
    db.refresh(db_advertiser)
    
    return db_advertiser


@router.get("", response_model=list[AdvertiserResponse])
def list_advertisers(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar todos os anunciantes"""
    advertisers = db.query(Advertiser).all()
    return advertisers


@router.get("/{advertiser_id}", response_model=AdvertiserResponse)
def get_advertiser(
    advertiser_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter anunciante por ID"""
    
    advertiser = db.query(Advertiser).filter(Advertiser.id == advertiser_id).first()
    
    if not advertiser:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertiser not found"
        )
    
    return advertiser


@router.put("/{advertiser_id}", response_model=AdvertiserResponse)
def update_advertiser(
    advertiser_id: int,
    advertiser_data: AdvertiserCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar anunciante (apenas admin)"""
    
    advertiser = db.query(Advertiser).filter(Advertiser.id == advertiser_id).first()
    
    if not advertiser:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertiser not found"
        )
    
    advertiser.name = advertiser_data.name
    advertiser.company_name = advertiser_data.company_name
    advertiser.email = advertiser_data.email
    advertiser.phone = advertiser_data.phone
    
    db.commit()
    db.refresh(advertiser)
    
    return advertiser


@router.delete("/{advertiser_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_advertiser(
    advertiser_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar anunciante (apenas admin)"""
    
    advertiser = db.query(Advertiser).filter(Advertiser.id == advertiser_id).first()
    
    if not advertiser:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Advertiser not found"
        )
    
    db.delete(advertiser)
    db.commit()
