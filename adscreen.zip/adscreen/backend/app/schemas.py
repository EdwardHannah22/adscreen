from pydantic import BaseModel, EmailStr, Field
from datetime import datetime
from typing import Optional, List
from app.models import UserRole, DeviceStatus, CampaignStatus, PaymentStatus


class UserBase(BaseModel):
    name: str
    email: EmailStr
    role: UserRole = UserRole.OPERATOR


class UserCreate(UserBase):
    password: str = Field(..., min_length=8)


class UserResponse(UserBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"


class AdvertiserBase(BaseModel):
    name: str
    company_name: str
    email: EmailStr
    phone: Optional[str] = None


class AdvertiserCreate(AdvertiserBase):
    pass


class AdvertiserResponse(AdvertiserBase):
    id: int
    user_id: Optional[int] = None
    created_at: datetime

    class Config:
        from_attributes = True


class EstablishmentBase(BaseModel):
    name: str
    address: str
    city: str
    state: str
    latitude: Optional[float] = None
    longitude: Optional[float] = None


class EstablishmentCreate(EstablishmentBase):
    pass


class EstablishmentResponse(EstablishmentBase):
    id: int
    status: str
    created_at: datetime

    class Config:
        from_attributes = True


class DeviceBase(BaseModel):
    name: str
    establishment_id: int


class DeviceCreate(DeviceBase):
    pass


class DeviceResponse(DeviceBase):
    id: int
    device_uuid: str
    status: DeviceStatus
    last_seen: Optional[datetime] = None
    client_version: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class DeviceRegistrationRequest(BaseModel):
    device_uuid: str
    device_name: str
    client_version: str


class DeviceHeartbeatRequest(BaseModel):
    device_uuid: str
    client_version: str


class CampaignBase(BaseModel):
    name: str
    description: Optional[str] = None
    start_date: datetime
    end_date: datetime
    status: CampaignStatus = CampaignStatus.DRAFT
    budget: float = 0


class CampaignCreate(CampaignBase):
    advertiser_id: int


class CampaignResponse(CampaignBase):
    id: int
    advertiser_id: int
    created_at: datetime

    class Config:
        from_attributes = True


class AdvertisementBase(BaseModel):
    title: str
    description: Optional[str] = None
    media_type: str  # video, image
    duration: int  # segundos


class AdvertisementCreate(AdvertisementBase):
    campaign_id: int


class AdvertisementResponse(AdvertisementBase):
    id: int
    campaign_id: int
    media_path: str
    file_hash: Optional[str] = None
    file_size: Optional[int] = None
    active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class DeviceAdvertisementBase(BaseModel):
    device_id: int
    advertisement_id: int
    priority: int = 0


class DeviceAdvertisementCreate(DeviceAdvertisementBase):
    pass


class ImpressionCreate(BaseModel):
    device_uuid: str
    advertisement_id: int
    started_at: datetime
    finished_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None


class ImpressionResponse(BaseModel):
    id: int
    device_id: int
    advertisement_id: int
    started_at: datetime
    finished_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None

    class Config:
        from_attributes = True


class StatisticsResponse(BaseModel):
    total_advertisers: int
    total_establishments: int
    total_devices: int
    devices_online: int
    devices_offline: int
    active_campaigns: int
    active_advertisements: int
    total_impressions: int
