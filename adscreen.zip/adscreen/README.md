# AdScreen - Plataforma de Publicidade Digital

Plataforma completa de publicidade digital que permite gerenciar anúncios em computadores instalados em estabelecimentos comerciais.

## 📋 Características

- 🎯 Gerenciamento centralizado de campanhas
- 📱 Dashboard web responsivo
- 💻 Cliente desktop para Windows
- 📹 Suporte para vídeos e imagens
- 🔐 Sistema de autenticação JWT
- 📊 Estatísticas e análises
- 📡 Sincronização offline
- 🌍 API REST completa

## 🏗️ Estrutura do Projeto

```
adscreen/
├── backend/          # FastAPI + SQLAlchemy + SQLite
├── frontend/         # React + TypeScript + Vite
├── client/           # Cliente Python para Windows
├── scripts/          # Scripts de inicialização
├── docs/             # Documentação
└── README.md
```

## 🚀 Instalação Rápida

### Requisitos

- Python 3.8+
- Node.js 16+
- pip
- npm

### 1. Backend (FastAPI)

```bash
cd backend
pip install -r requirements.txt
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

O backend estará disponível em: `http://localhost:8000`

### 2. Frontend (React)

```bash
cd frontend
npm install
npm run dev
```

O frontend estará disponível em: `http://localhost:5173`

### 3. Cliente (Python)

```bash
cd client
pip install -r requirements.txt
python main.py
```

## 📝 Credenciais de Teste

- **Email**: admin@example.com
- **Senha**: 12345678
- **Perfil**: Admin

## 🔧 Configuração

### Backend (.env)

```env
DATABASE_URL=sqlite:///./adscreen.db
SECRET_KEY=sua-chave-secreta-aqui
API_URL=http://localhost:8000
STORAGE_PATH=./storage
```

### Cliente (.env no diretório client)

```env
API_URL=http://localhost:8000
IDLE_TIMEOUT=300
```

## 🗄️ Banco de Dados

O projeto usa **SQLite** para desenvolvimento local. A estrutura inclui:

- **Users**: Usuários e permissões
- **Advertisers**: Anunciantes cadastrados
- **Establishments**: Estabelecimentos comerciais
- **Devices**: Computadores/Dispositivos
- **Campaigns**: Campanhas publicitárias
- **Advertisements**: Anúncios (vídeos/imagens)
- **Impressions**: Registros de exibições
- **Payments**: Histórico de pagamentos

## 📡 API REST

### Autenticação

```bash
POST /api/auth/login
{
  "email": "admin@example.com",
  "password": "12345678"
}
```

### Endpoints Principais

- `GET /api/statistics/dashboard` - Estatísticas do dashboard
- `GET /api/establishments` - Listar estabelecimentos
- `GET /api/devices` - Listar dispositivos
- `GET /api/campaigns` - Listar campanhas
- `GET /api/advertisements` - Listar anúncios

### Endpoints do Cliente

- `POST /api/devices/client/register` - Registrar cliente
- `POST /api/devices/client/heartbeat` - Enviar heartbeat
- `POST /api/impressions` - Registrar impressão
- `GET /api/client/advertisements/{device_uuid}` - Obter anúncios

## 👥 Perfis de Usuário

### Admin
- Acesso total ao sistema
- Gerenciar todos os usuários
- Configurar estabelecimentos e dispositivos
- Aprovar campanhas

### Advertiser
- Criar campanhas
- Upload de anúncios
- Visualizar estatísticas
- Acompanhar impressões

### Operator
- Gerenciar estabelecimentos
- Gerenciar dispositivos
- Visualizar status

## 📊 Fluxo de Funcionamento

1. **Admin** cadastra estabelecimentos e dispositivos
2. **Dispositivos** se registram automaticamente na API
3. **Advertiser** cria campanhas e faz upload de vídeos
4. **Admin** atribui anúncios aos dispositivos
5. **Cliente** detecta inatividade após X segundos
6. **Cliente** entra em modo fullscreen
7. **Anúncios** são reproduzidos em sequência
8. **Impressões** são registradas no servidor
9. **Dashboard** mostra estatísticas em tempo real

## 🔒 Segurança

- JWT para autenticação
- Senhas com hash bcrypt
- Validação Pydantic
- CORS configurado
- Validação de uploads
- Autorização por papel

## 📦 Upload de Vídeos

Os vídeos são salvos em:
```
storage/
  advertisements/
    {file_hash}.{extension}
```

Formatos suportados:
- Vídeo: MP4, WebM
- Imagem: PNG, JPG, GIF

Tamanho máximo: 500 MB

## 🔄 Sincronização Offline

O cliente possui cache local para:
- Anúncios já baixados
- Impressões pendentes de sincronização

Quando a internet volta:
1. Impressões são sincronizadas
2. Novos anúncios são baixados
3. Anúncios removidos são deletados

## 📈 Estatísticas

Dashboard apresenta:
- Total de anunciantes
- Total de estabelecimentos
- Status dos computadores
- Campanhas ativas
- Impressões por dia
- Impressões por anúncio
- Status dos dispositivos

## 🐛 Debugging

### Logs

- Backend: `backend/app.log` (via logging)
- Cliente: `client/storage/logs/client.log`

### Modo desenvolvimento

Backend com reload automático:
```bash
uvicorn app.main:app --reload
```

Frontend com hot reload:
```bash
npm run dev
```

## 📱 Funcionalidades Futuras

- [ ] Integração com Mercado Pago/Stripe
- [ ] Aplicativo mobile
- [ ] Análise avançada de dados
- [ ] Suporte a conteúdo interativo
- [ ] Geolocalização avançada
- [ ] Notificações em tempo real

## 🤝 Contribuindo

Para contribuir com o projeto:

1. Faça um fork
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📄 Licença

Este projeto é fornecido como está para fins educacionais e comerciais.

## 📞 Suporte

Para suporte, abra uma issue no repositório ou entre em contato através de:
- Email: support@adscreen.com
- Issues: GitHub Issues

## 🎯 Roadmap

### v1.0 (MVP Atual)
- ✅ Backend FastAPI
- ✅ Frontend React
- ✅ Cliente Python
- ✅ Autenticação JWT
- ✅ CRUD completo
- ✅ Estatísticas básicas

### v1.1 (Próxima)
- [ ] Pagamentos
- [ ] Notificações
- [ ] API WebSocket
- [ ] Testes automatizados
- [ ] Docker

### v2.0 (Futuro)
- [ ] Aplicativo mobile
- [ ] IA para otimização
- [ ] Análise preditiva
- [ ] Sistema multi-tenant

---

**Desenvolvido com ❤️ para publicidade digital**
